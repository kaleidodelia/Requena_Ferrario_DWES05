import pymysql.cursors
import datetime 

class RentACarroDatabase:
    def __init__(self):
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host='localhost',
                user='root',
                db='rentacarrout5',
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Connected to the RentACarro database.")
        except pymysql.Error as e:
            print("Error connecting to the RentACarro database:", e)

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Disconnected from the RentACarro database.")

    def execute_query(self, query):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(query)
                result = cursor.fetchall()
                cursor.close()  # Cerrar el cursor después de usarlo
                return result
        except (pymysql.Error, pymysql.MySQLError) as e:
            print("Error executing query:", e)

    def get_carros(self):
        query = "SELECT * FROM carros"
        return self.execute_query(query)


## RESERVAS
    def get_reservas(self):
        today = datetime.date.today()
        future_date = today + datetime.timedelta(days=7)
        query = f"SELECT * FROM reservas WHERE DATE(iniciReserva) BETWEEN '{today}' AND '{future_date}'"
        return self.execute_query(query)

    def get_reservas_by_date(self, date):
        query = f"SELECT * FROM reservas WHERE DATE('{date}') BETWEEN DATE(iniciReserva) AND DATE(finalReserva)"
        return self.execute_query(query)



## USUARIS
    # Todos
    def get_usuaris(self):
        query = "SELECT id, nom, llinatges, email, telefon, username, alta FROM usuaris"
        return self.execute_query(query)

    # Por id
    def get_usuari_by_id(self, user_id):
        query = "SELECT id, nom, llinatges, email, telefon, username, alta FROM usuaris WHERE id = %s"
        print("Query:", query)  # Imprime la consulta SQL
        print("User ID:", user_id)  # Imprime el ID de usuario
        try:
            print("Ejecutando consulta...")
            with self.connection.cursor() as cursor:
                cursor.execute(query, (user_id,))
                result = cursor.fetchone()
                print("Resultado de la consulta:", result)  # Imprime el resultado de la consulta
                return result
        except pymysql.Error as e:
            print("Error al ejecutar la consulta:", e)

    def delete_usuari(self, user_id):
        try:
            # Conectarse a la base de datos
            self.connect()

            # Verificar si el usuario existe antes de intentar eliminarlo
            if not self.get_usuari_by_id(user_id):
                print("Usuario no encontrado")
                return "Usuario no encontrado"

            # Crear la consulta para eliminar el usuario por su ID
            query = "DELETE FROM usuaris WHERE id = '{}'".format(user_id)

            print(query)
            # Ejecutar la consulta
            self.execute_query(query)
            self.connection.commit()
            # Desconectarse de la base de datos
            self.disconnect()
            print('DELETED SUCCESSFULLY')
        except Exception as e:
            print("Error al eliminar el usuario:", e)




#### RESERVAS POR USUARIO
    def get_reservas_by_user_id(self, user_id):
        with self.connection.cursor() as cursor:
            query = f"""
                SELECT 
                    reservas.finalReserva,
                    reservas.id_user,
                    reservas.iniciReserva,
                    carros.nom AS nombre_carro 
                FROM 
                    reservas 
                JOIN 
                    carros 
                ON 
                    reservas.idcarro = carros.id 
                WHERE 
                    reservas.id_user = {user_id}
            """
            cursor.execute(query)
            return cursor.fetchall()
        
        
        ##
        
    def obtener_precio_carro_por_id(self, id_carro):
        query = f"SELECT preu FROM carros WHERE id = {id_carro}"
        resultado = self.execute_query(query)
        if resultado:
            return resultado[0]['preu']  # Devuelve el precio del primer carro encontrado
        else:
            return None  # Retorna None si no se encontró ningún carro con ese ID
        
        
        
    def calcular_costo_reserva(self, preu, iniciReserva, finalReserva):
        # Convertir las fechas de string a objetos datetime
        fecha_inicio = datetime.datetime.strptime(iniciReserva, '%Y-%m-%d')
        fecha_final = datetime.datetime.strptime(finalReserva, '%Y-%m-%d')

        # Calcular la diferencia de días entre las fechas de inicio y final de la reserva
        diferencia_dias = (fecha_final - fecha_inicio).days

        # Calcular el costo total de la reserva multiplicando el precio por la cantidad de días
        costo_total = preu * diferencia_dias

        return costo_total

    def verificar_disponibilidad_carro(self, idcarro, fecha_inicio, fecha_final):
        try:
            with self.connection.cursor() as cursor:
                # Consulta para verificar si hay alguna reserva para el carro dado en las fechas dadas
                query = """
                        SELECT COUNT(*) AS count FROM reservas 
                        WHERE idcarro = %s 
                        AND DATE(iniciReserva) <= DATE(%s) 
                        AND DATE(finalReserva) >= DATE(%s)
                        """
                cursor.execute(query, (idcarro, fecha_final, fecha_inicio))

                # Obtenemos el resultado de la consulta
                result = cursor.fetchone()

                # Si hay una reserva existente, el carro no está disponible
                return result['count'] == 0
        except pymysql.Error as e:
            print("Error executing query:", e)

    def add_reserva(self, id_user, datos_reserva):
        fecha_inicio = datos_reserva.get('iniciReserva')
        fecha_final = datos_reserva.get('finalReserva')
        idcarro = datos_reserva.get('idcarro')
        
        # Verificar disponibilidad del carro
        disponibilidad = self.verificar_disponibilidad_carro(idcarro, fecha_inicio, fecha_final)
        if not disponibilidad:
            return None  # Carro no disponible
        
        # Obtener el precio del carro
        precio_carro = self.obtener_precio_carro_por_id(idcarro)
        
        # Calcular el costo de la reserva
        costo_reserva = self.calcular_costo_reserva(precio_carro, fecha_inicio, fecha_final)
        
        with self.connection.cursor() as cursor:
            # Insertar la reserva en la base de datos
            query = "INSERT INTO reservas (id_user, idcarro, iniciReserva, finalReserva) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (id_user, idcarro, fecha_inicio, fecha_final))
            self.connection.commit()
        
        return costo_reserva

    def delete_reserva(self, id_user, idcarro):
        with self.connection.cursor() as cursor:
            # Verificar si la reserva pertenece al usuario
            query = "SELECT * FROM reservas WHERE idcarro = %s AND id_user = %s"
            cursor.execute(query, (idcarro, id_user))
            reserva = cursor.fetchone()
            if not reserva:
                return False  # Reserva no encontrada o no pertenece al usuario
            
            # Eliminar la reserva
            query = "DELETE FROM reservas WHERE idcarro = %s"
            cursor.execute(query, (idcarro,))
            self.connection.commit()
            
        return True

if __name__ == "__main__":
    rentacarro_db = RentACarroDatabase()
    rentacarro_db.connect()
    carros = rentacarro_db.get_carros()
    print("Carros:")
    print(carros)
    reservas = rentacarro_db.get_reservas()
    print("Reservas:")
    print(reservas)
    usuaris = rentacarro_db.get_usuaris()
    print("Usuaris:")
    print(usuaris)
    rentacarro_db.disconnect()
