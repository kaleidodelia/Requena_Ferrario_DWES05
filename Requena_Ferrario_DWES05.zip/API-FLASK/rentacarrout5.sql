  -- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-09-2023 a las 10:51:55
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `rentacarrout5`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros`
--

CREATE TABLE `carros` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `clase` enum('basic','1cavall','2cavalls') NOT NULL,
  `preu` float NOT NULL,
  `descripcio` varchar(250) NOT NULL,
  `img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carros`
--

INSERT INTO `carros` (`id`, `nom`, `clase`, `preu`, `descripcio`, `img`) VALUES
(1, 'Carro simple', 'basic', 75, 'Un carro economic i familiar', 'carro1.png'),
(2, 'Western', 'basic', 90, 'Preparat per la conquesta de l\'oest!', 'carro2.png'),
(3, 'Utilitari 2px', '1cavall', 105, 'Amb aquest carretó seràs l\'enveja de les veinades', 'carro3.png'),
(4, 'Deportiu', '2cavalls', 180, 'Si t\'agrada la velocitat', 'carro4.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `idcarro` int(11) NOT NULL,
  `iniciReserva` datetime NOT NULL,
  `finalReserva` datetime NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`idcarro`, `iniciReserva`, `finalReserva`, `id_user`) VALUES
(1, '2024-02-24 04:00:00', '2024-02-28 08:00:00', 4),
(1, '2024-03-18 18:00:00', '2024-03-22 12:00:00', 3),
(1, '2024-06-07 03:00:00', '2024-06-09 05:00:00', 2),
(2, '2024-02-20 01:00:00', '2024-02-21 02:00:00', 1),
(2, '2024-03-01 03:00:00', '2024-03-08 02:00:00', 2),
(2, '2024-03-19 00:00:00', '2024-03-20 00:00:00', 4),
(2, '2024-05-03 02:00:00', '2024-05-09 08:00:00', 3),
(2, '2024-05-10 03:00:00', '2024-05-16 02:00:00', 2),
(3, '2024-01-26 07:00:00', '2024-01-28 05:00:00', 4),
(4, '2023-12-20 03:00:00', '2023-12-22 09:00:00', 1),
(4, '2023-12-23 01:00:00', '2023-12-27 21:00:00', 2),
(4, '2024-01-27 05:00:00', '2024-01-30 03:00:00', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuaris`
--

CREATE TABLE `usuaris` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nom` varchar(30) NOT NULL,
  `llinatges` varchar(80) NOT NULL,
  `telefon` varchar(15) NOT NULL,
  `alta` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuaris`
--

INSERT INTO `usuaris` (`id`, `username`, `password`, `email`, `nom`, `llinatges`, `telefon`, `alta`) VALUES
(1, 'usuariExemple', 'pbkdf2:sha256:260000$TzBeADDnIrB4iR7h$55823d7722b907be3832566165a3ac62a8b7926f9cf7f6ff63824183d4548a1c', 'exemple@gmail.com', 'usuari', 'dwes', '971764499', '2023-09-25 00:00:00'),
(2, 'user1', 'pbkdf2:sha256:260000$TzBeADDnIrB4iR7h$55823d7722b907be3832566165a3ac62a8b7926f9cf7f6ff63824183d4548a1c', 'user1@hotmail.com', 'usuario', 'primero', '999111222', '2023-09-27 11:16:07'),
(3, 'usuario', 'pbkdf2:sha256:260000$TzBeADDnIrB4iR7h$55823d7722b907be3832566165a3ac62a8b7926f9cf7f6ff63824183d4548a1c', 'usuaria@hltmail.com', 'user', 'segundo', '334567892', '2023-09-26 06:00:07'),
(4, 'torito', 'pbkdf2:sha256:260000$TzBeADDnIrB4iR7h$55823d7722b907be3832566165a3ac62a8b7926f9cf7f6ff63824183d4548a1c', 'torete@gmail.com', 'toro', 'bravo', '971764476', '2023-09-22 00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carros`
--
ALTER TABLE `carros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`idcarro`,`iniciReserva`),
  ADD KEY `id_user` (`id_user`);

--
-- Indices de la tabla `usuaris`
--
ALTER TABLE `usuaris`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carros`
--
ALTER TABLE `carros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_ibfk_1` FOREIGN KEY (`idcarro`) REFERENCES `carros` (`id`),
  ADD CONSTRAINT `reservas_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `usuaris` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
