from flask import Flask, jsonify
from flask_restful import Api, Resource
from database import RentACarroDatabase
from flask import request
from werkzeug.security import generate_password_hash


app = Flask(__name__)
api = Api(app)
rentacarro_db = RentACarroDatabase()

## CARROS
class CarrosResource(Resource):
    def get(self):
        rentacarro_db.connect()
        carros = rentacarro_db.get_carros()
        rentacarro_db.disconnect()
        return jsonify(carros)



## RESERVAS 
class ReservasResource(Resource):
    def get(self, date=None):
        rentacarro_db.connect()
        
        if date:
            reserves = rentacarro_db.get_reservas_by_date(date)
            if reserves:
                response = jsonify(reserves)
            else:
                response = {"message": "No hay reservas para la fecha especificada"}, 404
        else:
            reserves = rentacarro_db.get_reservas()
            response = jsonify(reserves)
            
        rentacarro_db.disconnect()
        return response



## USUARIOS
class UsuarisResource(Resource):
    def get(self, user_id=None):
        # Si no se proporciona un user_id
        if user_id is None:
            # Conexión a la base de datos
            rentacarro_db.connect()

            # Obtener todos los usuarios
            usuaris = rentacarro_db.get_usuaris()

            # Desconexión de la base de datos
            rentacarro_db.disconnect()

            # Devolver todos los usuarios como respuesta
            return jsonify(usuaris)

        # Conexión a la base de datos
        rentacarro_db.connect()

        # Intenta obtener el usuario por su ID
        usuario = rentacarro_db.get_usuari_by_id(user_id)

        # Desconexión de la base de datos
        rentacarro_db.disconnect()

        # Si se encontró el usuario, devolverlo como respuesta
        if usuario:
            return jsonify(usuario)

        # Si el usuario no se encontró, devolver un mensaje de error
        return {"message": "Usuario no encontrado"}, 404
    
    
    def post(self):
        # Obtener los datos del usuario del cuerpo de la solicitud
        datos_usuario = request.json
        
        # Generar el hash de la contraseña del usuario
        hashed_password = generate_password_hash(datos_usuario['password'], method='pbkdf2')
        
        # Agregar el hash de la contraseña al objeto de datos del usuario
        datos_usuario['password'] = hashed_password
        
        # Conexión a la base de datos
        rentacarro_db.connect()
                
        # Obtener el último ID de la tabla
        query_id = "SELECT MAX(id) FROM usuaris"
        last_id = rentacarro_db.execute_query(query_id)
        last_id = last_id[0]['MAX(id)']
        print(last_id)
        
        # Calcular el próximo ID autoincrementado
        next_id = last_id + 1 if last_id is not None else 1
        
        # Insertar el nuevo usuario en la base de datos
        query = "INSERT INTO usuaris (id, username, password, email, nom, llinatges, telefon, alta) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')".format(
            next_id,
            datos_usuario['username'],
            datos_usuario['password'],
            datos_usuario['email'],
            datos_usuario['nom'],
            datos_usuario['llinatges'],
            datos_usuario['telefon'],
            datos_usuario['diaalta']
        )
        print(query)
        rentacarro_db.execute_query(query)
        rentacarro_db.connection.commit()

        # Desconexión de la base de datos
        rentacarro_db.disconnect()
        return {"message": "Usuario agregado correctamente"}, 201
    
    def put(self, user_id):
        # Obtener los datos actualizados del usuario del cuerpo de la solicitud
        datos_usuario_actualizados = request.json

        # Conexión a la base de datos
        rentacarro_db.connect()

        # Verificar si el usuario existe en la base de datos
        usuario_existente = rentacarro_db.get_usuari_by_id(user_id)
        if not usuario_existente:
            rentacarro_db.disconnect()
            return {"message": "Usuario no encontrado"}, 404

        # Verificar si se proporcionó una nueva contraseña
        if 'password' in datos_usuario_actualizados:
            # Generar el hash de la nueva contraseña
            hashed_password = generate_password_hash(datos_usuario_actualizados['password'], method='pbkdf2')
            # Reemplazar la contraseña original con la nueva contraseña hasheada
            datos_usuario_actualizados['password'] = hashed_password

        # Construir la consulta de actualización
        query = "UPDATE usuaris SET "
        for key, value in datos_usuario_actualizados.items():
            query += f"{key} = '{value}', "
        query = query[:-2]  # Eliminar la coma y el espacio al final
        query += f" WHERE id = {user_id}"
        
        print(query)

        # Ejecutar la consulta de actualización
        rentacarro_db.execute_query(query)
        rentacarro_db.connection.commit()

        # Desconexión de la base de datos
        rentacarro_db.disconnect()

        return {"message": "Usuario actualizado correctamente"}, 200

    def delete(self, user_id):
            rentacarro_db.connect()
            if not rentacarro_db.get_usuari_by_id(user_id):
                    print("Usuario no encontrado")
                    return {"message": "Usuario no encontrado"}, 404
            rentacarro_db.disconnect()
                
            # Eliminar el usuario con el ID especificado
            rentacarro_db.delete_usuari(user_id)
            return {"message": "Usuario eliminado correctamente"}, 200
            

## RESERVAS X ID
class ReservasUsuarioResource(Resource):
    def get(self, user_id):
        # Conexión a la base de datos
        rentacarro_db.connect()

        # Obtener las reservas del usuario por su ID
        reservas_usuario = rentacarro_db.get_reservas_by_user_id(user_id)

        # Desconexión de la base de datos
        rentacarro_db.disconnect()

        # Si se encontraron reservas para el usuario, devolverlas como respuesta
        if reservas_usuario:
            return jsonify(reservas_usuario)

        # Si no se encontraron reservas, devolver un mensaje de error
        return {"message": "No se encontraron reservas para el usuario"}, 404
    
    def post(self, id_user):
            datos_reserva = request.json
            
            # Conexión a la base de datos
            rentacarro_db.connect()
            costo_reserva = rentacarro_db.add_reserva(id_user, datos_reserva)
            # Desconexión de la base de datos
            rentacarro_db.disconnect()

            if costo_reserva is not None:
                return {"message": "Reserva agregada correctamente", "costo_reserva": costo_reserva}, 201
            else:
                return {"message": "El carro está reservado en las fechas especificadas"}, 400
        
    def delete(self, id_user):
        # Obtener el idcarro de la reserva a eliminar del cuerpo de la solicitud
        idcarro = request.json.get('idcarro')
        
        # Conexión a la base de datos
        rentacarro_db.connect()

        # Eliminar la reserva del usuario con el ID especificado
        rentacarro_db.delete_reserva(id_user, idcarro)

        # Desconexión de la base de datos
        rentacarro_db.disconnect()

        return {"message": "Reserva eliminada correctamente"}, 200





    
## RUTAS ---------------------------------------------------------------------------------
api.add_resource(CarrosResource, '/rentacarro/carros')
api.add_resource(ReservasResource, '/rentacarro/reserves', '/rentacarro/reserves/<string:date>')
api.add_resource(UsuarisResource, '/rentacarro/usuaris', '/rentacarro/usuari', '/rentacarro/usuari/<int:user_id>')
api.add_resource(ReservasUsuarioResource, '/rentacarro/reserves/usuari/<int:id_user>')

if __name__ == '__main__':
    app.run(debug=True)
